#!/bin/bash
java -jar StageDisplayViewer-jfx.jar
